﻿namespace dazuoye2
{
    partial class Student_info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Student_info));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelsno = new System.Windows.Forms.Label();
            this.labelsname = new System.Windows.Forms.Label();
            this.labelssex = new System.Windows.Forms.Label();
            this.labelsphone = new System.Windows.Forms.Label();
            this.labelsbirth = new System.Windows.Forms.Label();
            this.labelsage = new System.Windows.Forms.Label();
            this.labelsdept = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonselect = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.OliveDrab;
            this.label1.Location = new System.Drawing.Point(222, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "个人信息";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "学    号：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "姓    名：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "性    别：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 268);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "联系方式：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(78, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "出生日期：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(78, 363);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "年    龄：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(78, 412);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "专    业：";
            // 
            // labelsno
            // 
            this.labelsno.AutoSize = true;
            this.labelsno.Location = new System.Drawing.Point(194, 125);
            this.labelsno.Name = "labelsno";
            this.labelsno.Size = new System.Drawing.Size(55, 15);
            this.labelsno.TabIndex = 8;
            this.labelsno.Text = "label9";
            // 
            // labelsname
            // 
            this.labelsname.AutoSize = true;
            this.labelsname.Location = new System.Drawing.Point(194, 174);
            this.labelsname.Name = "labelsname";
            this.labelsname.Size = new System.Drawing.Size(63, 15);
            this.labelsname.TabIndex = 9;
            this.labelsname.Text = "label10";
            // 
            // labelssex
            // 
            this.labelssex.AutoSize = true;
            this.labelssex.Location = new System.Drawing.Point(194, 219);
            this.labelssex.Name = "labelssex";
            this.labelssex.Size = new System.Drawing.Size(63, 15);
            this.labelssex.TabIndex = 10;
            this.labelssex.Text = "label11";
            // 
            // labelsphone
            // 
            this.labelsphone.AutoSize = true;
            this.labelsphone.Location = new System.Drawing.Point(194, 268);
            this.labelsphone.Name = "labelsphone";
            this.labelsphone.Size = new System.Drawing.Size(63, 15);
            this.labelsphone.TabIndex = 11;
            this.labelsphone.Text = "label12";
            // 
            // labelsbirth
            // 
            this.labelsbirth.AutoSize = true;
            this.labelsbirth.Location = new System.Drawing.Point(194, 317);
            this.labelsbirth.Name = "labelsbirth";
            this.labelsbirth.Size = new System.Drawing.Size(63, 15);
            this.labelsbirth.TabIndex = 12;
            this.labelsbirth.Text = "label13";
            // 
            // labelsage
            // 
            this.labelsage.AutoSize = true;
            this.labelsage.Location = new System.Drawing.Point(194, 363);
            this.labelsage.Name = "labelsage";
            this.labelsage.Size = new System.Drawing.Size(63, 15);
            this.labelsage.TabIndex = 13;
            this.labelsage.Text = "label14";
            // 
            // labelsdept
            // 
            this.labelsdept.AutoSize = true;
            this.labelsdept.Location = new System.Drawing.Point(194, 412);
            this.labelsdept.Name = "labelsdept";
            this.labelsdept.Size = new System.Drawing.Size(55, 15);
            this.labelsdept.TabIndex = 14;
            this.labelsdept.Text = "label9";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(431, 107);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(314, 271);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // buttonselect
            // 
            this.buttonselect.Location = new System.Drawing.Point(587, 432);
            this.buttonselect.Name = "buttonselect";
            this.buttonselect.Size = new System.Drawing.Size(57, 49);
            this.buttonselect.TabIndex = 17;
            this.buttonselect.Text = "关闭";
            this.buttonselect.UseVisualStyleBackColor = true;
            this.buttonselect.Click += new System.EventHandler(this.buttonselect_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(700, 432);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(57, 49);
            this.button1.TabIndex = 18;
            this.button1.Text = "退出";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Student_info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 505);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonselect);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelsdept);
            this.Controls.Add(this.labelsage);
            this.Controls.Add(this.labelsbirth);
            this.Controls.Add(this.labelsphone);
            this.Controls.Add(this.labelssex);
            this.Controls.Add(this.labelsname);
            this.Controls.Add(this.labelsno);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Student_info";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student_info";
            this.Load += new System.EventHandler(this.Student_info_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelsno;
        private System.Windows.Forms.Label labelsname;
        private System.Windows.Forms.Label labelssex;
        private System.Windows.Forms.Label labelsphone;
        private System.Windows.Forms.Label labelsbirth;
        private System.Windows.Forms.Label labelsage;
        private System.Windows.Forms.Label labelsdept;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonselect;
        private System.Windows.Forms.Button button1;
    }
}