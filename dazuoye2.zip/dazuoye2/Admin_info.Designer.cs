﻿namespace dazuoye2
{
    partial class Admin_info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_info));
            this.buttonselect = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1info = new System.Windows.Forms.Label();
            this.labelAno = new System.Windows.Forms.Label();
            this.labelAname = new System.Windows.Forms.Label();
            this.labelAsalary = new System.Windows.Forms.Label();
            this.labelAtitle = new System.Windows.Forms.Label();
            this.labelno = new System.Windows.Forms.Label();
            this.labelname = new System.Windows.Forms.Label();
            this.labelsex = new System.Windows.Forms.Label();
            this.labelsalary = new System.Windows.Forms.Label();
            this.labeltitle = new System.Windows.Forms.Label();
            this.labelAphone = new System.Windows.Forms.Label();
            this.labelAbirth = new System.Windows.Forms.Label();
            this.labelphone = new System.Windows.Forms.Label();
            this.labelbirth = new System.Windows.Forms.Label();
            this.labelAsex = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonselect
            // 
            this.buttonselect.Location = new System.Drawing.Point(469, 430);
            this.buttonselect.Name = "buttonselect";
            this.buttonselect.Size = new System.Drawing.Size(57, 49);
            this.buttonselect.TabIndex = 2;
            this.buttonselect.Text = "关闭";
            this.buttonselect.UseVisualStyleBackColor = true;
            this.buttonselect.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(420, 106);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(297, 285);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1info
            // 
            this.label1info.AutoSize = true;
            this.label1info.Font = new System.Drawing.Font("宋体", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1info.ForeColor = System.Drawing.Color.OliveDrab;
            this.label1info.Location = new System.Drawing.Point(202, 20);
            this.label1info.Name = "label1info";
            this.label1info.Size = new System.Drawing.Size(265, 60);
            this.label1info.TabIndex = 4;
            this.label1info.Text = "个人信息";
            // 
            // labelAno
            // 
            this.labelAno.AutoSize = true;
            this.labelAno.Location = new System.Drawing.Point(62, 106);
            this.labelAno.Name = "labelAno";
            this.labelAno.Size = new System.Drawing.Size(84, 15);
            this.labelAno.TabIndex = 5;
            this.labelAno.Text = "工    号：";
            // 
            // labelAname
            // 
            this.labelAname.AutoSize = true;
            this.labelAname.Location = new System.Drawing.Point(62, 159);
            this.labelAname.Name = "labelAname";
            this.labelAname.Size = new System.Drawing.Size(84, 15);
            this.labelAname.TabIndex = 7;
            this.labelAname.Text = "姓    名：";
            // 
            // labelAsalary
            // 
            this.labelAsalary.AutoSize = true;
            this.labelAsalary.Location = new System.Drawing.Point(62, 364);
            this.labelAsalary.Name = "labelAsalary";
            this.labelAsalary.Size = new System.Drawing.Size(84, 15);
            this.labelAsalary.TabIndex = 10;
            this.labelAsalary.Text = "工    资：";
            this.labelAsalary.Click += new System.EventHandler(this.labelAsalary_Click);
            // 
            // labelAtitle
            // 
            this.labelAtitle.AutoSize = true;
            this.labelAtitle.Location = new System.Drawing.Point(62, 414);
            this.labelAtitle.Name = "labelAtitle";
            this.labelAtitle.Size = new System.Drawing.Size(84, 15);
            this.labelAtitle.TabIndex = 11;
            this.labelAtitle.Text = "职    称：";
            // 
            // labelno
            // 
            this.labelno.AutoSize = true;
            this.labelno.Location = new System.Drawing.Point(165, 106);
            this.labelno.Name = "labelno";
            this.labelno.Size = new System.Drawing.Size(0, 15);
            this.labelno.TabIndex = 12;
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Location = new System.Drawing.Point(165, 159);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(0, 15);
            this.labelname.TabIndex = 13;
            // 
            // labelsex
            // 
            this.labelsex.AutoSize = true;
            this.labelsex.Location = new System.Drawing.Point(165, 212);
            this.labelsex.Name = "labelsex";
            this.labelsex.Size = new System.Drawing.Size(0, 15);
            this.labelsex.TabIndex = 14;
            // 
            // labelsalary
            // 
            this.labelsalary.AutoSize = true;
            this.labelsalary.Location = new System.Drawing.Point(165, 364);
            this.labelsalary.Name = "labelsalary";
            this.labelsalary.Size = new System.Drawing.Size(0, 15);
            this.labelsalary.TabIndex = 15;
            // 
            // labeltitle
            // 
            this.labeltitle.AutoSize = true;
            this.labeltitle.Location = new System.Drawing.Point(165, 414);
            this.labeltitle.Name = "labeltitle";
            this.labeltitle.Size = new System.Drawing.Size(0, 15);
            this.labeltitle.TabIndex = 16;
            // 
            // labelAphone
            // 
            this.labelAphone.AutoSize = true;
            this.labelAphone.Location = new System.Drawing.Point(62, 262);
            this.labelAphone.Name = "labelAphone";
            this.labelAphone.Size = new System.Drawing.Size(82, 15);
            this.labelAphone.TabIndex = 17;
            this.labelAphone.Text = "联系方式：";
            // 
            // labelAbirth
            // 
            this.labelAbirth.AutoSize = true;
            this.labelAbirth.Location = new System.Drawing.Point(62, 311);
            this.labelAbirth.Name = "labelAbirth";
            this.labelAbirth.Size = new System.Drawing.Size(82, 15);
            this.labelAbirth.TabIndex = 18;
            this.labelAbirth.Text = "出生日期：";
            // 
            // labelphone
            // 
            this.labelphone.AutoSize = true;
            this.labelphone.Location = new System.Drawing.Point(165, 262);
            this.labelphone.Name = "labelphone";
            this.labelphone.Size = new System.Drawing.Size(0, 15);
            this.labelphone.TabIndex = 19;
            // 
            // labelbirth
            // 
            this.labelbirth.AutoSize = true;
            this.labelbirth.Location = new System.Drawing.Point(165, 311);
            this.labelbirth.Name = "labelbirth";
            this.labelbirth.Size = new System.Drawing.Size(0, 15);
            this.labelbirth.TabIndex = 20;
            // 
            // labelAsex
            // 
            this.labelAsex.AutoSize = true;
            this.labelAsex.Location = new System.Drawing.Point(62, 212);
            this.labelAsex.Name = "labelAsex";
            this.labelAsex.Size = new System.Drawing.Size(84, 15);
            this.labelAsex.TabIndex = 21;
            this.labelAsex.Text = "性    别：";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(628, 430);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(57, 49);
            this.button1.TabIndex = 22;
            this.button1.Text = "退出";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Admin_info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(777, 519);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelAsex);
            this.Controls.Add(this.labelbirth);
            this.Controls.Add(this.labelphone);
            this.Controls.Add(this.labelAbirth);
            this.Controls.Add(this.labelAphone);
            this.Controls.Add(this.labeltitle);
            this.Controls.Add(this.labelsalary);
            this.Controls.Add(this.labelsex);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.labelno);
            this.Controls.Add(this.labelAtitle);
            this.Controls.Add(this.labelAsalary);
            this.Controls.Add(this.labelAname);
            this.Controls.Add(this.labelAno);
            this.Controls.Add(this.label1info);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonselect);
            this.Name = "Admin_info";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_info";
            this.Load += new System.EventHandler(this.Admin_info_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonselect;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1info;
        private System.Windows.Forms.Label labelAno;
        private System.Windows.Forms.Label labelAname;
        private System.Windows.Forms.Label labelAsalary;
        private System.Windows.Forms.Label labelAtitle;
        private System.Windows.Forms.Label labelno;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label labelsex;
        private System.Windows.Forms.Label labelsalary;
        private System.Windows.Forms.Label labeltitle;
        private System.Windows.Forms.Label labelAphone;
        private System.Windows.Forms.Label labelAbirth;
        private System.Windows.Forms.Label labelphone;
        private System.Windows.Forms.Label labelbirth;
        private System.Windows.Forms.Label labelAsex;
        private System.Windows.Forms.Button button1;
    }
}